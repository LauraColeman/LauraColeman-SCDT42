var person = {
    
    firstname: "Simon",
    lastName: "West",
    ageInYears: 33,
    
    get age() {
        return this.ageInYears;
        
    }
    
    
}
    
